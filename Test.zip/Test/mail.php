<?php

$name = $_POST['name'];
$company = $_POST['company'];  
$phone = $_POST['phone']; 
$email = $_POST['email']; 
$message = $_POST['message']; 
$subject = "Message from Website!"

$mailHeader = "From: ".$name."<".$email.">\r\n";
$mailTo = "jonathan.dikteruk@gmail.com";

mail($mailTo,$subject, $message, $mailHeader);
or die("Error!");

echo'Thanks!'; //Insert Thank You.html html
?>