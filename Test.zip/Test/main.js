const form = document.getElementById('form');
const name = document.getElementById('name');
const email = document.getElementById('email');
const company = document.getElementById('company');
const phone = document.getElementById('phone');
const message = document.getElementById('message');
//
function ProcessForm()
{
	var emailSend = "Name: " + name.value + "E-Mail: " + email.value + "Message: " + message.value;
	
	console.log(emailSend);
}